package processor.pipeline;

public class IF_EnableLatchType {
	
	boolean IF_enable;
	
	public IF_EnableLatchType()
	{
		IF_enable = true;
	}

	public void setIF_enable(boolean if_enable) {
		IF_enable = if_enable;
	}

	public boolean isIF_enable() {
		return IF_enable;
	}

}
